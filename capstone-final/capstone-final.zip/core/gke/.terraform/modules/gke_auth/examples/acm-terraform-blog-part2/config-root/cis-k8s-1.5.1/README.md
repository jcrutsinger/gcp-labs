CIS Kubernetes Benchmark v.1.5.1
==================================================

## Description

These constraints are intended to address the recommendations the CIS Kubernetes Benchmark v.1.5.1. They have not been certified by CIS.
